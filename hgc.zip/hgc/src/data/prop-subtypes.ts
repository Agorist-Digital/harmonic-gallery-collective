export enum Icon {
    Twitter = "twitter",
    Instagram = "instagram",
    Copyright = "copyright",
}

export enum Size {
    Small = "small",
    Medium = "medium",
    Large = "large",
}